main = True
img = True
auth = False
Random = False
R_data = ""