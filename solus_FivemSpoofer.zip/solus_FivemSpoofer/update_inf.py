main = True
img = False
auth = False
Random = False
R_data = ""