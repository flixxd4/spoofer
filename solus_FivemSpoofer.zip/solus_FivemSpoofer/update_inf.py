main = True
img = False
auth = False
Random = True
R_data = "img/test.txt"